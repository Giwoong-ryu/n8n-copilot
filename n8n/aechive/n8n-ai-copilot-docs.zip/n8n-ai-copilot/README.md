# 🤖 N8N AI Copilot

> N8N을 누구나 쉽게 사용할 수 있게 만드는 AI 코파일럿

## 📌 프로젝트 한눈에 보기

**무엇을?** Chrome Extension으로 N8N 사용자에게 실시간 AI 도움 제공  
**왜?** API 연동, OAuth 설정, JSON 작성이 너무 어려움  
**어떻게?** AI가 N8N 화면 옆에서 자동으로 설정 채우고 에러 해결

## 🚀 빠른 시작 (클로드 코드용)

### 처음 시작할 때
```bash
# 1. 현재 상태 파악
cat CURRENT_STATUS.md

# 2. 다음 작업 확인
# → CURRENT_STATUS.md의 "다음 작업" 섹션 참고

# 3. 상세 계획 보기
cat ROADMAP.md
```

### 주요 문서들
- **CURRENT_STATUS.md** ← 🔥 가장 먼저 읽을 것!
- **ROADMAP.md** - 개발 단계별 계획
- **TECHNICAL_SPEC.md** - 기술 스펙
- **PROJECT_OVERVIEW.md** - 비전과 전략

## 📁 프로젝트 구조

```
n8n-ai-copilot/
├── extension/              # Chrome Extension 소스
│   ├── manifest.json
│   ├── content.js
│   ├── background.js
│   ├── popup.html
│   └── sidebar.css
├── website/                # 마케팅 웹사이트 (Phase 2)
└── docs/                   # 상세 문서
```

## 🎯 현재 단계

**Phase**: MVP 개발 중  
**마지막 업데이트**: 2025-10-31  
**다음 마일스톤**: CORS 에러 해결

---

📖 **자세한 내용은 각 문서 파일 참고**
