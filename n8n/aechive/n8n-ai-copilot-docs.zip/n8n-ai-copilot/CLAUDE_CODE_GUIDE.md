# 🤖 클로드 코드 작업 가이드

> **이 파일은 클로드 코드(Haiku 4.5)가 최초에 읽어야 하는 문서입니다**

## 📍 시작 전 필독 순서

```bash
# 1단계: 현재 상태 파악 (필수!)
cat CURRENT_STATUS.md

# 2단계: 이번 주 작업 확인
cat ROADMAP.md | grep -A 30 "Week 1"

# 3단계: 기술 스펙 참고 (필요시)
cat TECHNICAL_SPEC.md
```

---

## 🎯 현재 작업: Week 1 - 기술 안정화

### 목표
Extension이 N8N에서 완벽하게 작동

### 작업 디렉토리
```
/home/claude/n8n-ai-copilot/extension/
```

### 주요 파일
- `manifest.json` - Extension 설정
- `background.js` - Claude API 호출 (CORS 해결)
- `content.js` - N8N DOM 조작 + 사이드바
- `popup.html` - 설정 화면
- `popup.js` - 설정 로직
- `sidebar.css` - UI 스타일

---

## 🔧 작업 1: CORS 에러 해결 (Day 1-2)

### 문제 상황
```
❌ Access to fetch at 'https://api.anthropic.com/v1/messages' 
   from origin 'chrome-extension://...' blocked by CORS
```

### 원인
Content Script에서 직접 API 호출 시도

### 해결 방법

#### Step 1: background.js 수정
```javascript
// 파일 경로: extension/background.js

// Claude API 호출 함수
async function callClaudeAPI(prompt, apiKey) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2048,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('❌ Claude API Error:', error);
    throw error;
  }
}

// 메시지 리스너
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'callClaude') {
    const { prompt, apiKey } = request;
    
    callClaudeAPI(prompt, apiKey)
      .then(response => {
        sendResponse({ success: true, data: response });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    
    return true; // 비동기 응답 유지
  }
});

console.log('✅ Background script loaded');
```

#### Step 2: content.js 수정
```javascript
// 파일 경로: extension/content.js

// AI 요청 함수 (기존 fetch 코드 제거)
async function callAI(prompt) {
  try {
    // API 키 가져오기
    const { apiKey } = await chrome.storage.sync.get('apiKey');
    
    if (!apiKey) {
      throw new Error('API 키가 설정되지 않았습니다');
    }
    
    // Background로 요청 전달
    const response = await chrome.runtime.sendMessage({
      action: 'callClaude',
      prompt: prompt,
      apiKey: apiKey
    });
    
    if (!response.success) {
      throw new Error(response.error);
    }
    
    return response.data;
  } catch (error) {
    console.error('❌ AI 호출 에러:', error);
    throw error;
  }
}

// 사용 예시
async function handleUserMessage(message) {
  try {
    showLoading(true);
    
    const context = collectContext();
    const prompt = buildPrompt(message, context);
    const response = await callAI(prompt);
    
    displayResponse(response);
  } catch (error) {
    displayError(error.message);
  } finally {
    showLoading(false);
  }
}
```

#### Step 3: manifest.json 확인
```json
// 파일 경로: extension/manifest.json

{
  "host_permissions": [
    "*://n8nryugw10.site/*",
    "*://*.n8n.io/*",
    "https://api.anthropic.com/*"  // ← 이 줄 확인
  ]
}
```

### 테스트
```
1. Extension 리로드
2. N8N 페이지 새로고침
3. 사이드바 열기
4. 메시지 전송
5. Console 확인: CORS 에러 없어야 함
```

---

## 🎨 작업 2: UI 화면 전환 (Day 3-4)

### 문제 상황
```
API 키 저장 성공 → 그러나 메인 화면으로 안 넘어감
```

### 해결 방법

#### Step 1: popup.html 구조 추가
```html
<!-- 파일 경로: extension/popup.html -->

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { width: 300px; padding: 15px; }
    .screen { display: none; }
    .screen.active { display: block; }
    .success { color: green; }
    .error { color: red; }
  </style>
</head>
<body>
  
  <!-- 인증 화면 -->
  <div id="authScreen" class="screen active">
    <h3>N8N AI Copilot</h3>
    <p>Claude API 키를 입력하세요</p>
    <input type="password" id="apiKeyInput" placeholder="sk-ant-...">
    <button id="saveBtn">저장</button>
    <div id="authMessage"></div>
  </div>
  
  <!-- 메인 화면 -->
  <div id="mainScreen" class="screen">
    <h3>N8N AI Copilot</h3>
    <p>사용 준비 완료!</p>
    <div>
      <strong>API 키:</strong> ●●●●●●
    </div>
    <div>
      <strong>상태:</strong> <span class="success">활성</span>
    </div>
    <button id="changeKeyBtn">API 키 변경</button>
  </div>
  
  <script src="popup.js"></script>
</body>
</html>
```

#### Step 2: popup.js 로직 수정
```javascript
// 파일 경로: extension/popup.js

// 초기화
document.addEventListener('DOMContentLoaded', async () => {
  // API 키 확인
  const { apiKey } = await chrome.storage.sync.get('apiKey');
  
  if (apiKey) {
    showMainScreen();
  } else {
    showAuthScreen();
  }
  
  // 이벤트 리스너
  document.getElementById('saveBtn').addEventListener('click', saveApiKey);
  document.getElementById('changeKeyBtn').addEventListener('click', showAuthScreen);
});

// 화면 전환 함수
function showAuthScreen() {
  document.getElementById('authScreen').classList.add('active');
  document.getElementById('mainScreen').classList.remove('active');
}

function showMainScreen() {
  document.getElementById('authScreen').classList.remove('active');
  document.getElementById('mainScreen').classList.add('active');
}

// API 키 저장
async function saveApiKey() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const messageEl = document.getElementById('authMessage');
  
  if (!apiKey.startsWith('sk-ant-')) {
    messageEl.textContent = '❌ 잘못된 API 키 형식';
    messageEl.className = 'error';
    return;
  }
  
  try {
    // 저장
    await chrome.storage.sync.set({ apiKey });
    
    // 성공 메시지
    messageEl.textContent = '✅ 저장 완료!';
    messageEl.className = 'success';
    
    // 1초 후 메인 화면으로
    setTimeout(() => {
      showMainScreen();
    }, 1000);
    
  } catch (error) {
    messageEl.textContent = '❌ 저장 실패: ' + error.message;
    messageEl.className = 'error';
  }
}
```

---

## 🧪 작업 3: 테스트 (Day 5-7)

### 테스트 시나리오

```bash
# 시나리오 1: 설치 → 인증 → 메인
1. Extension 설치
2. popup 열기
3. API 키 입력
4. "저장" 클릭
✅ 메인 화면으로 전환

# 시나리오 2: N8N → 사이드바
1. N8N 페이지 접속
2. 페이지 새로고침
3. 사이드바 확인
✅ 떠 있어야 함

# 시나리오 3: 메시지 전송
1. 사이드바에서 메시지 입력
2. "전송" 클릭
✅ AI 응답 표시
✅ CORS 에러 없음

# 시나리오 4: 자동 입력
1. HTTP 노드 선택
2. AI에게 "카카오 API 설정"
3. [N8N에 입력] 클릭
✅ 필드 자동 채워짐

# 시나리오 5: 에러 처리
1. 잘못된 API 키 입력
2. 메시지 전송
✅ 적절한 에러 메시지
```

---

## 📝 작업 완료 보고 양식

작업 완료 후 다음 형식으로 보고:

```
## 완료 작업
- [x] CORS 에러 해결 (background.js, content.js 수정)
- [x] UI 화면 전환 (popup.html, popup.js 수정)
- [x] 테스트 시나리오 5개 통과

## 변경 파일
- extension/background.js (API 호출 함수 추가)
- extension/content.js (fetch → sendMessage 변경)
- extension/popup.html (메인 화면 추가)
- extension/popup.js (화면 전환 로직)

## 테스트 결과
✅ CORS 에러 해결됨
✅ 화면 전환 정상 작동
✅ AI 응답 수신 성공
⚠️ 발견된 문제: [있다면 기재]

## 다음 작업
- [ ] N8N DOM 조작 개선
- [ ] 에러 처리 강화
```

---

## 🚨 주의사항

### Haiku 모델 최적화
```
❌ 나쁜 예:
"먼저 파일 확인해줘"
"그 다음 수정해줘"
"결과 보여줘"

✅ 좋은 예:
"extension/background.js 확인하고
callClaudeAPI 함수 추가한 다음
변경사항 요약해줘"
```

### 파일 경로
```
항상 절대 경로 사용:
/home/claude/n8n-ai-copilot/extension/background.js

상대 경로 사용 금지:
./extension/background.js  ❌
```

### 에러 처리
```
모든 비동기 함수에 try-catch:
try {
  const result = await someFunction();
} catch (error) {
  console.error('❌ 에러:', error);
}
```

---

## 📚 참고 문서

작업 중 막힐 때:
- **TECHNICAL_SPEC.md** - 기술 스펙 상세
- **ROADMAP.md** - 전체 계획
- **CURRENT_STATUS.md** - 현재 상태

---

**작업 시작 명령어:**
```bash
cat CURRENT_STATUS.md && echo "\n다음 작업을 시작하겠습니다"
```
